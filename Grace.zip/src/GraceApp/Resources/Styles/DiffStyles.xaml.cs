namespace GraceApp;

public partial class DiffStyles : ResourceDictionary
{
	public DiffStyles()
	{
		InitializeComponent();
	}
}