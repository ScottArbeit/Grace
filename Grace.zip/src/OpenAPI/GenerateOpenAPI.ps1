$directoryPath = "C:\Source\Grace\src\OpenAPI"

# Get all .yaml files in the directory, except for the main OpenAPI specifications file
$files = Get-ChildItem -Path $directoryPath | Where-Object { $_.PSIsContainer -eq $false } | Where-Object { $_.Name -like "*.yaml" } | Where-Object { $_.Name -notlike "Grace.OpenAPI.yaml" }

# Sort the files alphabetically by name
$sortedFiles = $files | Sort-Object -Property Name

# Concatenate the file names into a string separated by spaces, starting with the main OpenAPI specifications file
$concatenatedNames = 'Grace.OpenAPI.yaml ' + ($sortedFiles | ForEach-Object { $_.Name }) -join ' '

# Run redocly-cli to generate the documentation
$commandLine = "redocly bundle -o C:\Source\Grace\src\OpenAPI\Grace.OpenAPI.yaml --dereferenced --force --format stylish C:\Source\Grace\src\OpenAPI\Main.OpenAPI.yaml"
Invoke-Expression $commandLine
