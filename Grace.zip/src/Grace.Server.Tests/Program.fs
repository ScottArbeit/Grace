namespace Grace.Server.Tests

open NUnit.Framework

module Program =

    [<EntryPoint>]
    let main _ = 0
