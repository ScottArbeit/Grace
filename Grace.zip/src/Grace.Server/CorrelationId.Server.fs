// Create asp.net core middleware to ensure "X-Correlation-ID" header is set on all requests and responses.
