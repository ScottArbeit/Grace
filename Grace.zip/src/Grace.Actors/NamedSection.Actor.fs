﻿namespace Grace.Actors

open Grace.Actors.Constants

module NamedSection =

    let ActorName = ActorName.NamedSection
